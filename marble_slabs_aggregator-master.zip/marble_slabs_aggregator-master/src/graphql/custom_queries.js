export const categoryProducts = /* GraphQL */ `
    query categoryProducts {
    getCategory(id: "10mm") {
        products {
        items {
            id
            price
            seller {
            id
            }
            url
        }
        }
    }
    }
`;

export const listCategoryOptions = /* GraphQL */ `
    query listCategoryOptions{
        listCategories{
        items{
            id
        }
        }
    }
`;

export const listPriceOptions = /* GraphQL */ `
query listPriceOptions($thickness: ID!) {
  getCategory(id: $thickness) {
    products(sortDirection: ASC) {
      items {
        price
      }
    }
  }
}
`;