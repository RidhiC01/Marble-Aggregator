
import React from 'react';

function ThicknessSelector({ thickness, setThickness, thicknessOptions }) {
  return (
    <div>
      <label htmlFor="thickness">Select Thickness:</label>
      <select
        id="thickness"
        value={thickness}
        onChange={(e) => setThickness(e.target.value)}
      >
        {thicknessOptions.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </div>
  );
}

export default ThicknessSelector;