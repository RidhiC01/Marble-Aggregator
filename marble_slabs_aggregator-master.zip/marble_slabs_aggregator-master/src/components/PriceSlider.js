
import React from 'react';

function PriceSlider({ price, setPrice, priceOptions }) {
  // Handle invalid input
  if (!Array.isArray(priceOptions)) {
    return <div>Loading prices...</div>;
  }
  
  priceOptions = [...new Set(priceOptions)];

  return (
    <div className="price-selector">
      <label htmlFor="price">Select Price:</label>
      <select
        id="price"
        value={price}
        onChange={(e) => setPrice(Number(e.target.value))}
      >
        <option value={-1}>Select a price</option>
        {priceOptions.map((option) => (
          <option key={option} value={option}>
            ${option}
          </option>
        ))}
      </select>
      <span>Selected: {price === -1 ? 'None' : `$${price}`}</span>
    </div>
  );
}

export default PriceSlider;