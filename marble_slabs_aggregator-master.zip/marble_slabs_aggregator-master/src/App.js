import React, { useState, useEffect } from 'react';
import { Amplify } from 'aws-amplify';
import { generateClient } from 'aws-amplify/api';
import config from './aws-exports';
import { categoryProducts, listCategoryOptions, listPriceOptions } from './graphql/custom_queries';
import { Collection, Image } from '@aws-amplify/ui-react';
import ThicknessSelector from './components/ThicknessSelector';
import PriceSlider from './components/PriceSlider';
import './App.css';

Amplify.configure(config);
const API = generateClient();

function filterProducts(products, price){
  if(price==-1){
    return [];
  }
  let filteredProducts = products.filter((product) => product.price <= price);
  products = filteredProducts;
  return products;
}

async function fetchUrls(thickness, price, setUrls){
  if(thickness==""){
    return;
  }
  let response = await API.graphql({
    query: categoryProducts,
    variables: { thickness: thickness }
  });
  console.log(response)
  let products = response.data.getCategory.products.items;
  products = filterProducts(products, price);
  console.log(products)
  setUrls(products);
}

function Images({urls}){
  const images = urls.map((url) => {
    return (
      <Image
        src = {url}
      />
    );
  });
  return (
    <Collection
      images = {images}
    />
  );
}

function App() {
  const [urls, setUrls] = useState([]);
  const [thickness, setThickness] = useState(''); // flag: validate when creating data
  const [thicknessOptions, setThicknessOptions] = useState(['']);
  const [price, setPrice] = useState(-1); // flag: validate when creating data
  const [priceOptions, setPriceOptions] = useState([-1]);

  useEffect(() => {
    const fetchCategoriesData = async () => {
      const result = await API.graphql({ query: listCategoryOptions });
      // console.log(result)
      setThicknessOptions(result.data.listCategories.items.map((item) => item.id));
    };
    fetchCategoriesData();
  }, []);

  useEffect(() => {
    const fetchPricesData = async () => {
      if(thickness==""){
        return;
      }
      const result = await API.graphql({
        query: listPriceOptions,
        variables: { thickness: thickness }
      });
      // console.log(result)
      // console.log(errors)
      setPriceOptions(result.data.getCategory.products.items.map((item) => item.price));
    };
    fetchPricesData();
  }, [thickness]);

  useEffect(() => {
    const fetchData = async () => {
      await fetchUrls(thickness, price, setUrls);
    };
    fetchData();
  }, [thickness, price]);

  return (
    <>
      <h1> Marble Slabs Aggregator </h1>
      <Images
        urls = {urls}
      />
      <ThicknessSelector
        thickness = {thickness}
        setThickness = {setThickness}
        thicknessOptions = {thicknessOptions}
      />
      <PriceSlider
        price = {price}
        setPrice = {setPrice}
        priceOptions = {priceOptions}
      />
    </>
  );
}

export default App;
